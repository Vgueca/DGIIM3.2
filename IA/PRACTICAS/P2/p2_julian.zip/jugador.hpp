#ifndef COMPORTAMIENTOJUGADOR_H
#define COMPORTAMIENTOJUGADOR_H

#include "comportamientos/comportamiento.hpp"

#include <list>
#include <queue>
#include <string>

struct estado {
  int fila;
  int columna;
  int orientacion;

  bool bikini = false;
  bool zapatillas = false;
};

class ComportamientoJugador : public Comportamiento {
  public:
    ComportamientoJugador(unsigned int size) : Comportamiento(size) { // Para NIVELES 3 y 4
      // Inicializar Variables de Estado
      hay_plan = false;
      actual.bikini = false;
      actual.zapatillas = false;
      brujula_inicial = 0;
      inicializar_nivel = true;
      empezar_girando = true;
      casilla_actual = '?';
      contador_recarga = 0;
      instantes_tiempo = 0;
      //objetivo_random
      o_random = false;
      //planB

      // Level 3 GO
      girarDerecha = false;
      andandoConPrecipicioAIzquierda = false;
      andandoConPrecipicioADerecha = false;
      ultimaAccion = actIDLE;
      casillasSeguidasDePrecipicioAIzquierda = 0;
      casillasSeguidasDePrecipicioADerecha = 0;
      types = "ABMP";
    }
    ComportamientoJugador(std::vector< std::vector< unsigned char> > mapaR) : Comportamiento(mapaR) { // Para NIVELES 0, 1 y 2
      // Inicializar Variables de Estado
      hay_plan = false;
      actual.bikini = false;
      actual.zapatillas = false;
    }
    ComportamientoJugador(const ComportamientoJugador & comport) : Comportamiento(comport){
      // COMPLETAR SI ES NECESARIO

        // variable actual
      actual.fila = comport.actual.fila;
      actual.columna = comport.actual.columna;
      actual.orientacion = comport.actual.orientacion;

        // variable objetivos
      objetivos = comport.objetivos;

        // variable plan
      plan = comport.plan;

        // variable hay_plan
      hay_plan = comport.hay_plan;

        // variables bikini y zapatillas
      actual.bikini = comport.actual.bikini;
      actual.zapatillas = comport.actual.zapatillas;

    }
    ~ComportamientoJugador(){}

    Action think(Sensores sensores);
    int interact(Action accion, int valor);
    void VisualizaPlan(const estado &st, const list<Action> &plan);
    ComportamientoJugador * clone(){return new ComportamientoJugador(*this);}

  private:
    // Declarar Variables de Estado
    estado actual;
    list<estado> objetivos;
    list<Action> plan;
    bool hay_plan;
    bool inicializar_nivel;
    int brujula_inicial;
    bool empezar_girando;
    char casilla_actual;
    int contador_recarga;
    int instantes_tiempo;
    estado objetivo_random;
    bool o_random;
    list<Action> planB;

    // Level 3 GO
    bool girarDerecha, andandoConPrecipicioAIzquierda, andandoConPrecipicioADerecha;
    int casillasSeguidasDePrecipicioAIzquierda, casillasSeguidasDePrecipicioADerecha;
    int lastCol;
    Action ultimaAccion;
    string types;

    // Métodos privados de la clase
    bool pathFinding(int level, const estado &origen, const list<estado> &destino, list<Action> &plan, Sensores sensores);
    bool pathFinding_Profundidad(const estado &origen, const estado &destino, list<Action> &plan);

    // (Creados por mi)
    bool pathFinding_Anchura(const estado &origen, const estado &destino, list<Action> &plan);
    bool pathFinding_CostoUniforme(const estado &origen, const estado &destino, list<Action> &plan);
    bool pathFinding_Descubrir(const estado &origen, list<Action> &plan, Sensores sensores);
    
    void inicializarNivel_3(Sensores Sensores);
    Action empezarGirando();
    void ActualizarVariablesEstado(Sensores sensores);
    int veoAccesorio(Sensores sensores, char a);
    int getFil(int brujula, int pos);
    int getCol(int brujula, int pos);
    void localizaObjetivo(estado &objetivo, int casilla);
    list<Action> irAccesorio(int posicion);

    // Level 3 GO
    list<Action> SalirEntornoHostil(Sensores sensores);
    Action getRandomTurn();
    list<Action> decideAction(Sensores sensores);
    bool noEs(const char casilla, const string tipos);
    bool rodeado (const string tipos);
    
    void pintarVista(Sensores sensores);

    void PintaPlan(list<Action> plan);
    bool HayObstaculoDelante(estado &st);

    bool EsObstaculo(unsigned char casilla);
};

#endif
