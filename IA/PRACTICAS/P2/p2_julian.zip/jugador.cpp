#include "../Comportamientos_Jugador/jugador.hpp"
#include "motorlib/util.h"

#include <iostream>
#include <cmath>
#include <set>
#include <stack>

// Mis includes
#include <queue>

// Este es el método principal que se piden en la practica.
// Tiene como entrada la información de los sensores y devuelve la acción a realizar.
// Para ver los distintos sensores mirar fichero "comportamiento.hpp"
Action ComportamientoJugador::think(Sensores sensores)
{
	Action accion = actIDLE;

	// Actualizar variable actual
	actual.fila = sensores.posF;
	actual.columna = sensores.posC;
	actual.orientacion = sensores.sentido;

	/*
	cout << "Fila: " << actual.fila << endl;
	cout << "Col : " << actual.columna << endl;
	cout << "Ori : " << actual.orientacion << endl;
	*/

	// Capturo los destinos
	//cout << "sensores.num_destinos : " << sensores.num_destinos << endl;
	objetivos.clear();
	for (int i = 0; i < sensores.num_destinos; i++){
		estado aux;
		aux.fila = sensores.destino[2 * i];
		aux.columna = sensores.destino[2 * i + 1];
		objetivos.push_back(aux);
	}

	// Si no hay plan, construirlo
	if(!hay_plan){
		hay_plan = pathFinding(sensores.nivel, actual, objetivos, plan, sensores);
	}
	
	if(hay_plan && plan.size()>0){	// Hay un plan no vacío
		PintaPlan(plan);
		// ver el plan en el mapa
		VisualizaPlan(actual, plan);

		accion = plan.front();		// Tomar la siguiente acción del Plan

		bool new_plan;
		
		if(sensores.nivel==3){
			pintarVista(sensores);
			if((o_random && EsObstaculo(mapaResultado[objetivo_random.fila][objetivo_random.columna])) || (accion == actFORWARD && EsObstaculo(sensores.terreno[2]))){
				plan.clear();
				objetivo_random.fila = -1;
				objetivo_random.columna = -1;
				o_random = false;
				plan = decideAction(sensores);
				new_plan =true;
			}
		}

		if(new_plan){
			accion = plan.front();		// Tomar la siguiente acción del Plan
			new_plan = false;
		}

		plan.erase(plan.begin()); 	// Eliminar la acción del Plan

		cout << endl << "RANDOM !!!!!! :" << to_string(o_random) << endl;
		cout << "Fila :" << to_string(objetivo_random.fila) << endl;
		cout << "Columna :" << to_string(objetivo_random.columna) << endl;

		if(plan.empty()){
			hay_plan=false;
			objetivo_random.fila = -1;
			objetivo_random.columna = -1;
			o_random = false;
			//accion = actIDLE;
		}
		
	}
	else {
		cout << "No se pudo encontrar un plan\n";
	}

	ultimaAccion = accion;
	instantes_tiempo++;
	return accion;
}

// Llama al algoritmo de busqueda que se usara en cada comportamiento del agente
// Level representa el comportamiento en el que fue iniciado el agente.
bool ComportamientoJugador::pathFinding(int level, const estado &origen, const list<estado> &destino, list<Action> &plan, Sensores sensores)
{
	estado un_objetivo;
	switch (level)
	{
	case 0:
		cout << "Demo\n";
		un_objetivo = objetivos.front();
		cout << "fila: " << un_objetivo.fila << " col:" << un_objetivo.columna << endl;
		return pathFinding_Profundidad(origen, un_objetivo, plan);
		break;
	
	case 1:
		cout << "Optimo numero de acciones\n";
		// Incluir aqui la llamada al busqueda en anchura
		un_objetivo = objetivos.front();
		cout << "fila: " << un_objetivo.fila << " col:" << un_objetivo.columna << endl;
		return pathFinding_Anchura(origen, un_objetivo, plan);
		break;
	
	case 2:
		cout << "Optimo en coste\n";
		// Incluir aqui la llamada al busqueda de costo uniforme/A*
		un_objetivo = objetivos.front();
		cout << "fila: " << un_objetivo.fila << " col:" << un_objetivo.columna << endl;
		return pathFinding_CostoUniforme(origen, un_objetivo, plan);
		break;

	case 3:
		//cout << "Reto 1: Descubrir el mapa\n";
		// Incluir aqui la llamada al algoritmo de busqueda para el Reto 1
		return pathFinding_Descubrir(origen, plan, sensores);
		break;

	case 4:
		cout << "Reto 2: Maximizar objetivos\n";
		// Incluir aqui la llamada al algoritmo de busqueda para el Reto 2
		cout << "No implementado aun\n";
		break;
	}
	return false;
}

//---------------------- Implementación de la busqueda en profundidad ---------------------------

// Dado el codigo en caracter de una casilla del mapa dice si se puede
// pasar por ella sin riegos de morir o chocar.
bool ComportamientoJugador::EsObstaculo(unsigned char casilla)
{
	if (casilla == 'P' or casilla == 'M')
		return true;
	else
		return false;
}

// Comprueba si la casilla que hay delante es un obstaculo. Si es un
// obstaculo devuelve true. Si no es un obstaculo, devuelve false y
// modifica st con la posición de la casilla del avance.
bool ComportamientoJugador::HayObstaculoDelante(estado &st)
{
	int fil = st.fila, col = st.columna;

	// calculo cual es la casilla de delante del agente
	switch (st.orientacion)
	{
	case 0:
		fil--;
		break;
	case 1:
		fil--;
		col++;
		break;
	case 2:
		col++;
		break;
	case 3:
		fil++;
		col++;
		break;
	case 4:
		fil++;
		break;
	case 5:
		fil++;
		col--;
		break;
	case 6:
		col--;
		break;
	case 7:
		fil--;
		col--;
		break;
	}

	// Compruebo que no me salgo fuera del rango del mapa
	if (fil < 0 or fil >= mapaResultado.size())
		return true;
	if (col < 0 or col >= mapaResultado[0].size())
		return true;

	// Miro si en esa casilla hay un obstaculo infranqueable
	if (!EsObstaculo(mapaResultado[fil][col]))
	{
		// No hay obstaculo, actualizo el parametro st poniendo la casilla de delante.
		st.fila = fil;
		st.columna = col;
		return false;
	}
	else
	{
		return true;
	}
}

struct nodo
{
	estado st;
	list<Action> secuencia;
};
/*
struct ComparaEstados
{
	bool operator()(const estado &a, const estado &n) const
	{
		if ((a.fila > n.fila) or (a.fila == n.fila and a.columna > n.columna) or
			(a.fila == n.fila and a.columna == n.columna and a.orientacion > n.orientacion))
			return true;
		else
			return false;
	}
};
*/
struct ComparaEstados
{
	bool operator()(const estado &a, const estado &n) const
	{
		if ((a.fila > n.fila) or (a.fila == n.fila and a.columna > n.columna) or
			(a.fila == n.fila and a.columna == n.columna and a.orientacion > n.orientacion) or
			(a.fila == n.fila and a.columna == n.columna and a.orientacion == n.orientacion and a.bikini > n.bikini) or
			(a.fila == n.fila and a.columna == n.columna and a.orientacion == n.orientacion and a.bikini == n.bikini and a.zapatillas > n.zapatillas)
			)
			return true;
		else
			return false;
	}
};

// Implementación de la busqueda en profundidad.
// Entran los puntos origen y destino y devuelve la
// secuencia de acciones en plan, una lista de acciones.
bool ComportamientoJugador::pathFinding_Profundidad(const estado &origen, const estado &destino, list<Action> &plan)
{
	// Borro la lista
	cout << "Calculando plan\n";
	plan.clear();
	set<estado, ComparaEstados> Cerrados; // Lista de Cerrados
	stack<nodo> Abiertos;				  // Lista de Abiertos

	nodo current;
	current.st = origen;
	current.secuencia.empty();

	Abiertos.push(current);

	while (!Abiertos.empty() and (current.st.fila != destino.fila or current.st.columna != destino.columna))
	{

		Abiertos.pop();
		Cerrados.insert(current.st);

		// Generar descendiente de girar a la derecha 90 grados
		nodo hijoTurnR = current;
		hijoTurnR.st.orientacion = (hijoTurnR.st.orientacion + 2) % 8;
		if (Cerrados.find(hijoTurnR.st) == Cerrados.end())
		{
			hijoTurnR.secuencia.push_back(actTURN_R);
			Abiertos.push(hijoTurnR);
		}

		// Generar descendiente de girar a la derecha 45 grados
		nodo hijoSEMITurnR = current;
		hijoSEMITurnR.st.orientacion = (hijoSEMITurnR.st.orientacion + 1) % 8;
		if (Cerrados.find(hijoSEMITurnR.st) == Cerrados.end())
		{
			hijoSEMITurnR.secuencia.push_back(actSEMITURN_R);
			Abiertos.push(hijoSEMITurnR);
		}

		// Generar descendiente de girar a la izquierda 90 grados
		nodo hijoTurnL = current;
		hijoTurnL.st.orientacion = (hijoTurnL.st.orientacion + 6) % 8;
		if (Cerrados.find(hijoTurnL.st) == Cerrados.end())
		{
			hijoTurnL.secuencia.push_back(actTURN_L);
			Abiertos.push(hijoTurnL);
		}

		// Generar descendiente de girar a la izquierda 45 grados
		nodo hijoSEMITurnL = current;
		hijoSEMITurnL.st.orientacion = (hijoSEMITurnL.st.orientacion + 7) % 8;
		if (Cerrados.find(hijoSEMITurnL.st) == Cerrados.end())
		{
			hijoSEMITurnL.secuencia.push_back(actSEMITURN_L);
			Abiertos.push(hijoSEMITurnL);
		}

		// Generar descendiente de avanzar
		nodo hijoForward = current;
		if (!HayObstaculoDelante(hijoForward.st))
		{
			if (Cerrados.find(hijoForward.st) == Cerrados.end())
			{
				hijoForward.secuencia.push_back(actFORWARD);
				Abiertos.push(hijoForward);
			}
		}

		// Tomo el siguiente valor de la Abiertos
		if (!Abiertos.empty())
		{
			current = Abiertos.top();
		}
	}

	cout << "Terminada la busqueda\n";

	if (current.st.fila == destino.fila and current.st.columna == destino.columna)
	{
		cout << "Cargando el plan\n";
		plan = current.secuencia;
		cout << "Longitud del plan: " << plan.size() << endl;
		PintaPlan(plan);
		// ver el plan en el mapa
		VisualizaPlan(origen, plan);
		return true;
	}
	else
	{
		cout << "No encontrado plan\n";
	}

	return false;
}

//---------------------- Implementación de la busqueda en ANCHURA ---------------------------

// Implementación de la busqueda en anchura.
// Entran los puntos origen y destino y devuelve la
// secuencia de acciones en plan, una lista de acciones.
bool ComportamientoJugador::pathFinding_Anchura(const estado &origen, const estado &destino, list<Action> &plan)
{
	// Borro la lista
	cout << "Calculando plan\n";
	plan.clear();
	set<estado, ComparaEstados> Cerrados; // Lista de Cerrados
	queue<nodo> Abiertos;				  // Lista de Abiertos

	nodo current;
	current.st = origen;
	current.secuencia.empty(); // ??? Debería ser CLEAR

	bool encontrada = false;

	Abiertos.push(current);

	while (!Abiertos.empty() and (current.st.fila != destino.fila or current.st.columna != destino.columna))
	{

		Abiertos.pop();
		Cerrados.insert(current.st);

		// Generar descendiente de girar a la derecha 90 grados
		nodo hijoTurnR = current;
		hijoTurnR.st.orientacion = (hijoTurnR.st.orientacion + 2) % 8;
		if (Cerrados.find(hijoTurnR.st) == Cerrados.end())
		{
			hijoTurnR.secuencia.push_back(actTURN_R);
			Abiertos.push(hijoTurnR);
		}


		// Generar descendiente de girar a la derecha 45 grados
		nodo hijoSEMITurnR = current;
		hijoSEMITurnR.st.orientacion = (hijoSEMITurnR.st.orientacion + 1) % 8;
		if (Cerrados.find(hijoSEMITurnR.st) == Cerrados.end())
		{
			hijoSEMITurnR.secuencia.push_back(actSEMITURN_R);
			Abiertos.push(hijoSEMITurnR);
		}

		// Generar descendiente de girar a la izquierda 90 grados
		nodo hijoTurnL = current;
		hijoTurnL.st.orientacion = (hijoTurnL.st.orientacion + 6) % 8;
		if (Cerrados.find(hijoTurnL.st) == Cerrados.end())
		{
			hijoTurnL.secuencia.push_back(actTURN_L);
			Abiertos.push(hijoTurnL);
		}

		// Generar descendiente de girar a la izquierda 45 grados
		nodo hijoSEMITurnL = current;
		hijoSEMITurnL.st.orientacion = (hijoSEMITurnL.st.orientacion + 7) % 8;
		if (Cerrados.find(hijoSEMITurnL.st) == Cerrados.end())
		{
			hijoSEMITurnL.secuencia.push_back(actSEMITURN_L);
			Abiertos.push(hijoSEMITurnL);
		}

		// Generar descendiente de avanzar
		nodo hijoForward = current;
		if (!HayObstaculoDelante(hijoForward.st)) // Aquí se modifica fil y col de hijoForward
		{
			// Compruebo si el último elemento a añadir en Abiertos es el indicado y me salto el push para acelerar el proceso
			if(hijoForward.st.fila == destino.fila && hijoForward.st.columna == destino.columna){
				hijoForward.secuencia.push_back(actFORWARD);
				current = hijoForward;
				encontrada = true;
			}
			else if (Cerrados.find(hijoForward.st) == Cerrados.end())
			{
				hijoForward.secuencia.push_back(actFORWARD);
				Abiertos.push(hijoForward);
			}
		}
		
		if(!encontrada){
			// Quito de abiertos los que ya están en cerrados
			while (Cerrados.find(Abiertos.front().st)!=Cerrados.end()){
				Abiertos.pop();
			}

			// Tomo el siguiente valor de la Abiertos
			if (!Abiertos.empty())
			{
				current = Abiertos.front();
			}
		}
	}
	cout << "Terminada la busqueda\n";

	if (current.st.fila == destino.fila and current.st.columna == destino.columna)
	{
		cout << "Cargando el plan\n";
		plan = current.secuencia;
		cout << "Longitud del plan (NUMERO DE ACCIONES): " << plan.size() << endl;
		PintaPlan(plan);
		// ver el plan en el mapa
		VisualizaPlan(origen, plan);
		return true;
	}
	else
	{
		cout << "No encontrado plan\n";
	}

	return false;
}

//---------------------- Implementación de algoritmo de COSTO UNIFORME --------------------------- 

struct Node {
	estado st;
	list<Action> secuencia;
	int coste; // Coste en batería para llegar al nodo en cuestión
	//bool bik;
	//bool zap;
};

struct ComparaNodes {
	bool operator()(const Node &a, const Node &n) const
	{
		if (a.coste > n.coste)
			return true;
		else
			return false;
	}
};

int CalcularCosteAccion(const Action &accion, const estado &st, std::vector< std::vector< unsigned char> > mapaResultado, bool bikini, bool zapatillas){
	switch (accion) {
		case actFORWARD:
			switch (mapaResultado[st.fila][st.columna]) {
				case 'A':
					if(bikini) {return 10;} else {return 200;}	break;
				case 'B':
					if(zapatillas) {return 15;} else {return 100;}	break;
				case 'T':
					return 2;	break;
				case '?':
					return 50;	break;
				default:
					return 1;	break;
			}
			break;
		
		case actTURN_L:
			switch (mapaResultado[st.fila][st.columna]) {
				case 'A':
					if(bikini) {return 5;} else {return 500;}	break;
				case 'B':
					if(zapatillas) {return 1;} else {return 3;}	break;
				case 'T':
					return 2;	break;
				case '?':
					return 50;	break;
				default:
					return 1;	break;
			}
			break;

		case actTURN_R:
			switch (mapaResultado[st.fila][st.columna]) {
				case 'A':
					if(bikini) {return 5;} else {return 500;}	break;
				case 'B':
					if(zapatillas) {return 1;} else {return 3;}	break;
				case 'T':
					return 2;	break;
				case '?':
					return 50;	break;
				default:
					return 1;	break;
			}
			break;

		case actSEMITURN_L:
			switch (mapaResultado[st.fila][st.columna]) {
				case 'A':
					if(bikini) {return 2;} else {return 300;}	break;
				case 'B':
					if(zapatillas) {return 1;} else {return 2;}	break;
				case 'T':
					return 1;	break;
				case '?':
					return 50;	break;
				default:
					return 1;	break;
			}
			break;
		
		case actSEMITURN_R:
			switch (mapaResultado[st.fila][st.columna]) {
				case 'A':
					if(bikini) {return 2;} else {return 300;}	break;
				case 'B':
					if(zapatillas) {return 1;} else {return 2;}	break;
				case 'T':
					return 1;	break;
				case '?':
					return 50;	break;
				default:
					return 1;	break;
			}
			break;
		
		case actWHEREIS:
			return 200;
			break;
		
		case actIDLE:
			return 0;
			break;
	}
}
void Accesorios(Node &node, std::vector< std::vector< unsigned char> > mapaResultado){
	if(mapaResultado[node.st.fila][node.st.columna] == 'K'){
		node.st.zapatillas = false;
		node.st.bikini = true;
	}
	else if(mapaResultado[node.st.fila][node.st.columna] == 'D'){
		node.st.zapatillas = true;
		node.st.bikini = false;
	}
}

// Implementación de algoritmo de COSTO UNIFORME.
// Entran los puntos origen y destino y devuelve la
// secuencia de acciones en plan, una lista de acciones con el menor gasto de batería posible
bool ComportamientoJugador::pathFinding_CostoUniforme(const estado &origen, const estado &destino, list<Action> &plan)
{
	// Borro la lista
	cout << "Calculando plan\n";
	plan.clear();
	set<estado, ComparaEstados> Cerrados; // Lista de Cerrados
	priority_queue<Node, vector<Node>, ComparaNodes> Abiertos;				  // Lista de Abiertos

	Node current;
	current.st = origen;
	current.secuencia.empty(); // ??? Debería ser CLEAR
	current.coste = 0;

	bool encontrada = false;

	Accesorios(current, mapaResultado);
	Abiertos.push(current);

	while (!Abiertos.empty() and (current.st.fila != destino.fila or current.st.columna != destino.columna))
	{
		Accesorios(current, mapaResultado);
		Abiertos.pop();
		Cerrados.insert(current.st);

		// Generar descendiente de girar a la derecha 90 grados
		Node hijoTurnR = current;
		hijoTurnR.st.orientacion = (hijoTurnR.st.orientacion + 2) % 8;
		if (Cerrados.find(hijoTurnR.st) == Cerrados.end())
		{
			hijoTurnR.secuencia.push_back(actTURN_R);
			hijoTurnR.coste = current.coste + CalcularCosteAccion(actTURN_R, current.st, mapaResultado, hijoTurnR.st.bikini, hijoTurnR.st.zapatillas);
			Abiertos.push(hijoTurnR);
		}


		// Generar descendiente de girar a la derecha 45 grados
		Node hijoSEMITurnR = current;
		hijoSEMITurnR.st.orientacion = (hijoSEMITurnR.st.orientacion + 1) % 8;
		if (Cerrados.find(hijoSEMITurnR.st) == Cerrados.end())
		{
			hijoSEMITurnR.secuencia.push_back(actSEMITURN_R);
			hijoSEMITurnR.coste = current.coste + CalcularCosteAccion(actSEMITURN_R, current.st, mapaResultado, hijoSEMITurnR.st.bikini, hijoSEMITurnR.st.zapatillas);
			Abiertos.push(hijoSEMITurnR);
		}

		// Generar descendiente de girar a la izquierda 90 grados
		Node hijoTurnL = current;
		hijoTurnL.st.orientacion = (hijoTurnL.st.orientacion + 6) % 8;
		if (Cerrados.find(hijoTurnL.st) == Cerrados.end())
		{
			hijoTurnL.secuencia.push_back(actTURN_L);
			hijoTurnL.coste = current.coste + CalcularCosteAccion(actTURN_L, current.st, mapaResultado, hijoTurnL.st.bikini, hijoTurnL.st.zapatillas);
			Abiertos.push(hijoTurnL);
		}

		// Generar descendiente de girar a la izquierda 45 grados
		Node hijoSEMITurnL = current;
		hijoSEMITurnL.st.orientacion = (hijoSEMITurnL.st.orientacion + 7) % 8;
		if (Cerrados.find(hijoSEMITurnL.st) == Cerrados.end())
		{
			hijoSEMITurnL.secuencia.push_back(actSEMITURN_L);
			hijoSEMITurnL.coste = current.coste + CalcularCosteAccion(actSEMITURN_L, current.st, mapaResultado, hijoSEMITurnL.st.bikini, hijoSEMITurnL.st.zapatillas);
			Abiertos.push(hijoSEMITurnL);
		}

		// Generar descendiente de avanzar
		Node hijoForward = current;
		if (!HayObstaculoDelante(hijoForward.st)) // Aquí se modifica fil y col de hijoForward
		{
			// Compruebo si el último elemento a añadir en Abiertos es el indicado y me salto el push para acelerar el proceso
			if(hijoForward.st.fila == destino.fila && hijoForward.st.columna == destino.columna){
				hijoForward.secuencia.push_back(actFORWARD);
				hijoForward.coste = current.coste + CalcularCosteAccion(actFORWARD, current.st, mapaResultado, hijoForward.st.bikini, hijoForward.st.zapatillas);
				current = hijoForward;
				encontrada = true;
			}
			else if (Cerrados.find(hijoForward.st) == Cerrados.end())
			{
				hijoForward.secuencia.push_back(actFORWARD);
				hijoForward.coste = current.coste + CalcularCosteAccion(actFORWARD, current.st, mapaResultado, hijoForward.st.bikini, hijoForward.st.zapatillas);
				Abiertos.push(hijoForward);
			}
		}
		
		if(!encontrada){
			// Quito de abiertos los que ya están en cerrados
			while (Cerrados.find(Abiertos.top().st)!=Cerrados.end()){
				Abiertos.pop();
			}

			// Tomo el siguiente valor de la Abiertos
			if (!Abiertos.empty())
			{
				current = Abiertos.top();
			}
		}
		//cout << endl << "Abiertos: " << Abiertos.size();
		//cout << endl << "Cerrados: " << Cerrados.size() << endl;
	}
	cout << "Terminada la busqueda\n";

	if (current.st.fila == destino.fila and current.st.columna == destino.columna)
	{
		cout << "Cargando el plan\n";
		plan = current.secuencia;
		cout << "Longitud del plan (NUMERO DE ACCIONES): " << plan.size() << endl;
		cout << "COSTE del plan: " << current.coste << endl;
		PintaPlan(plan);
		// ver el plan en el mapa
		VisualizaPlan(origen, plan);
		return true;
	}
	else
	{
		cout << "No encontrado plan\n";
	}

	return false;
}

//---------------------- Implementación de algoritmo para DESCUBRIR --------------------------- 

// F. aux para pintar las 16 casillas que veo bien en mi memoria o en el mapa
void ComportamientoJugador::pintarVista(Sensores sensores){
	int casilla = 0;
	int fil = sensores.posF;
	int col = sensores.posC;
	switch (sensores.sentido)
	{
	case 0: // NORTE
		for(int i=0; i<4; i++){
			for(int j=-i; j<=i; j++){
				mapaResultado[fil-i][col+j] = sensores.terreno[casilla];
				casilla++;
			}
		}
		break;
	
	case 2: // ESTE
		for(int i=0; i<4; i++){
			for(int j=-i; j<=i; j++){
				mapaResultado[fil+j][col+i] = sensores.terreno[casilla];
				casilla++;
			}
		}
		break;

	case 4: // SUR
		for(int i=0; i<4; i++){
			for(int j=-i; j<=i; j++){
				mapaResultado[fil+i][col-j] = sensores.terreno[casilla];
				casilla++;
			}
		}
		break;

	case 6: // OESTE
		for(int i=0; i<4; i++){
			for(int j=-i; j<=i; j++){
				mapaResultado[fil-j][col-i] = sensores.terreno[casilla];
				casilla++;
			}
		}
		break;
	

	case 1: // NOR-ESTE		
		for(int i=0; i<4; i++){
			for(int j=0; j<2*i+1; j++){
				if(j<=i){
					mapaResultado[fil-i][col+j] = sensores.terreno[casilla];
					casilla++;
				}
				else{
					mapaResultado[fil-i+j-i][col+i] = sensores.terreno[casilla];
					casilla++;
				}
			}
		}
		break;
	
	case 3: // SUR-ESTE		
		for(int i=0; i<4; i++){
			for(int j=0; j<2*i+1; j++){
				if(j<=i){
					mapaResultado[fil+j][col+i] = sensores.terreno[casilla];
					casilla++;
				}
				else{
					mapaResultado[fil+i][col+i-j+i] = sensores.terreno[casilla];
					casilla++;
				}
			}
		}
		break;

	case 5: // SUR-OESTE	
		for(int i=0; i<4; i++){
			for(int j=0; j<2*i+1; j++){
				if(j<=i){
					mapaResultado[fil+i][col-j] = sensores.terreno[casilla];
					casilla++;
				}
				else{
					mapaResultado[fil+i-j+i][col-i] = sensores.terreno[casilla];
					casilla++;
				}
			}
		}
		break;
	
	case 7: // NOR-OESTE	
		for(int i=0; i<4; i++){
			for(int j=0; j<2*i+1; j++){
				if(j<=i){
					mapaResultado[fil-j][col-i] = sensores.terreno[casilla];
					casilla++;
				}
				else{
					mapaResultado[fil-i][col-i+j-i] = sensores.terreno[casilla];
					casilla++;
				}
			}
		}
		break;
	}
}

// Empezar con 3 giros según la orientación para conocer más del entorno
Action ComportamientoJugador::empezarGirando(){
	// Si no aparecemos en agua giramos
	if(casilla_actual !='A'){
		if(actual.orientacion == (brujula_inicial+6)%8){
			empezar_girando = false;
		}
		//return actSEMITURN_R;
		return actTURN_R;
	}
	else {
		empezar_girando = false;
		return actIDLE;
	}
}

// Inicializar todas las variables iniciales a los valoes correctos
void ComportamientoJugador::inicializarNivel_3(Sensores sensores){
	brujula_inicial = sensores.sentido;
	inicializar_nivel = false;
}

// Actualizar variables de estado
void ComportamientoJugador::ActualizarVariablesEstado(Sensores sensores){
	actual.fila = sensores.posF;
	actual.columna = sensores.posC;
	actual.orientacion = sensores.sentido;

	if(mapaResultado[actual.fila][actual.columna] == 'D'){
		actual.zapatillas = true;
		actual.bikini = false;
	}
	else if (mapaResultado[actual.fila][actual.columna] == 'K') {
		actual.zapatillas = false;
		actual.bikini = true;
	}

	if(actual.zapatillas){
		types = "AMP";
	}
	else if(actual.bikini){
		types = "BMP";
	}

	casilla_actual = sensores.terreno[0];

}

// Indica la casilla en la que se ve el objeto pasado como parámetro
int ComportamientoJugador::veoAccesorio(Sensores sensores, char a){
	if(sensores.sentido%2 != 0){
		int lejos[15] = {12, 13, 11, 14, 10, 6, 15, 9, 7, 5, 8, 4, 2, 1};
		for(int i=0; i<15; i++){
			if(sensores.terreno[lejos[i]] == a){
				return lejos[i];
			}
		}
	}
	else{
		for(int i=15; i>0; i--){
			if(sensores.terreno[i] == a){
				return i;
			}
		}
	}
	return -1;
}

// Obtener la fila (en relación a fil) en la que se encuentra una casilla de nuestro campo de vision según su ídice
    int ComportamientoJugador::getFil(int brujula, int pos){
      int fila;
	  int fil = actual.fila;
      switch (brujula){
        case 0:
          switch (pos){
            case 1: fila=fil-1; break;
            case 2: fila=fil-1; break;
            case 3: fila=fil-1; break;
            case 4: fila=fil-2; break;
            case 5: fila=fil-2; break;
            case 6: fila=fil-2; break;
            case 7: fila=fil-2; break;
            case 8: fila=fil-2; break;
            case 9: fila=fil-3; break;
            case 10: fila=fil-3; break;
            case 11: fila=fil-3; break;
            case 12: fila=fil-3; break;
            case 13: fila=fil-3; break;
            case 14: fila=fil-3; break;
            case 15: fila=fil-3; break;
            case 16: fila=fil; break;   //casilla a la derecha del jugador
            case 17: fila=fil+1; break; //casilla detras del jugador
            case 18: fila=fil; break;   //casilla a la izquierda del jugador
          }
        break;
        
        case 2:
          switch (pos){
            case 1: fila=fil-1; break;
            case 2: fila=fil; break;
            case 3: fila=fil+1; break;
            case 4: fila=fil-2; break;
            case 5: fila=fil-1; break;
            case 6: fila=fil; break;
            case 7: fila=fil+1; break;
            case 8: fila=fil+2; break;
            case 9: fila=fil-3; break;
            case 10: fila=fil-2; break;
            case 11: fila=fil-1; break;
            case 12: fila=fil; break;
            case 13: fila=fil+1; break;
            case 14: fila=fil+2; break;
            case 15: fila=fil+3; break;
            case 16: fila=fil+1; break; //casilla a la derecha del jugador
            case 17: fila=fil; break;   //casilla detras del jugador
            case 18: fila=fil-1; break; //casilla a la izquierda del jugador
          }
        break;

        case 4:
          switch (pos){
            case 1: fila=fil+1; break;
            case 2: fila=fil+1; break;
            case 3: fila=fil+1; break;
            case 4: fila=fil+2; break;
            case 5: fila=fil+2; break;
            case 6: fila=fil+2; break;
            case 7: fila=fil+2; break;
            case 8: fila=fil+2; break;
            case 9: fila=fil+3; break;
            case 10: fila=fil+3; break;
            case 11: fila=fil+3; break;
            case 12: fila=fil+3; break;
            case 13: fila=fil+3; break;
            case 14: fila=fil+3; break;
            case 15: fila=fil+3; break;
            case 16: fila=fil; break;   //casilla a la derecha del jugador
            case 17: fila=fil-1; break; //casilla detras del jugador
            case 18: fila=fil; break;   //casilla a la izquierda del jugador
          }
        break;

        case 6:
          switch (pos){
            case 1: fila=fil+1; break;
            case 2: fila=fil; break;
            case 3: fila=fil-1; break;
            case 4: fila=fil+2; break;
            case 5: fila=fil+1; break;
            case 6: fila=fil; break;
            case 7: fila=fil-1; break;
            case 8: fila=fil-2; break;
            case 9: fila=fil+3; break;
            case 10: fila=fil+2; break;
            case 11: fila=fil+1; break;
            case 12: fila=fil; break;
            case 13: fila=fil-1; break;
            case 14: fila=fil-2; break;
            case 15: fila=fil-3; break;
            case 16: fila=fil-1; break; //casilla a la derecha del jugador
            case 17: fila=fil; break;   //casilla detras del jugador
            case 18: fila=fil+1; break; //casilla a la izquierda del jugador
          }
        break;

		case 1:
          switch (pos){
            case 1: fila=fil-1; break;
            case 2: fila=fil-1; break;
            case 3: fila=fil; break;
            case 4: fila=fil-2; break;
            case 5: fila=fil-2; break;
            case 6: fila=fil-2; break;
            case 7: fila=fil-1; break;
            case 8: fila=fil; break;
            case 9: fila=fil-3; break;
            case 10: fila=fil-3; break;
            case 11: fila=fil-3; break;
            case 12: fila=fil-3; break;
            case 13: fila=fil-2; break;
            case 14: fila=fil-1; break;
            case 15: fila=fil; break;
            //case 16: fila=fil-1; break; //casilla a la derecha del jugador
            //case 17: fila=fil; break;   //casilla detras del jugador
            //case 18: fila=fil+1; break; //casilla a la izquierda del jugador
          }
        break;

		case 3:
          switch (pos){
            case 1: fila=fil; break;
            case 2: fila=fil+1; break;
            case 3: fila=fil+1; break;
            case 4: fila=fil; break;
            case 5: fila=fil+1; break;
            case 6: fila=fil+2; break;
            case 7: fila=fil+2; break;
            case 8: fila=fil+2; break;
            case 9: fila=fil; break;
            case 10: fila=fil+1; break;
            case 11: fila=fil+2; break;
            case 12: fila=fil+3; break;
            case 13: fila=fil+3; break;
            case 14: fila=fil+3; break;
            case 15: fila=fil+3; break;
            //case 16: fila=fil-1; break; //casilla a la derecha del jugador
            //case 17: fila=fil; break;   //casilla detras del jugador
            //case 18: fila=fil+1; break; //casilla a la izquierda del jugador
          }
        break;

		case 5:
          switch (pos){
            case 1: fila=fil+1; break;
            case 2: fila=fil+1; break;
            case 3: fila=fil; break;
            case 4: fila=fil+2; break;
            case 5: fila=fil+2; break;
            case 6: fila=fil+2; break;
            case 7: fila=fil+1; break;
            case 8: fila=fil; break;
            case 9: fila=fil+3; break;
            case 10: fila=fil+3; break;
            case 11: fila=fil+3; break;
            case 12: fila=fil+3; break;
            case 13: fila=fil+2; break;
            case 14: fila=fil+1; break;
            case 15: fila=fil; break;
            //case 16: fila=fil-1; break; //casilla a la derecha del jugador
            //case 17: fila=fil; break;   //casilla detras del jugador
            //case 18: fila=fil+1; break; //casilla a la izquierda del jugador
          }
        break;

		case 7:
          switch (pos){
            case 1: fila=fil; break;
            case 2: fila=fil-1; break;
            case 3: fila=fil-1; break;
            case 4: fila=fil; break;
            case 5: fila=fil-1; break;
            case 6: fila=fil-2; break;
            case 7: fila=fil-2; break;
            case 8: fila=fil-2; break;
            case 9: fila=fil; break;
            case 10: fila=fil-1; break;
            case 11: fila=fil-2; break;
            case 12: fila=fil-3; break;
            case 13: fila=fil-3; break;
            case 14: fila=fil-3; break;
            case 15: fila=fil-3; break;
            //case 16: fila=fil-1; break; //casilla a la derecha del jugador
            //case 17: fila=fil; break;   //casilla detras del jugador
            //case 18: fila=fil+1; break; //casilla a la izquierda del jugador
          }
        break;
      }
      return fila;
    }

    // Obtener la columna (en relación a col) en la que se encuentra una casilla de nuestro campo de vision según su ídice + EXTRAS
    int ComportamientoJugador::getCol(int brujula, int pos){
      int columna;
	  int col = actual.columna;
      switch (brujula){
        case 6:
          switch (pos){
            case 1: columna=col-1; break;
            case 2: columna=col-1; break;
            case 3: columna=col-1; break;
            case 4: columna=col-2; break;
            case 5: columna=col-2; break;
            case 6: columna=col-2; break;
            case 7: columna=col-2; break;
            case 8: columna=col-2; break;
            case 9: columna=col-3; break;
            case 10: columna=col-3; break;
            case 11: columna=col-3; break;
            case 12: columna=col-3; break;
            case 13: columna=col-3; break;
            case 14: columna=col-3; break;
            case 15: columna=col-3; break;
            case 16: columna=col; break;    //casilla a la derecha del jugador
            case 17: columna=col+1; break;  //casilla detras del jugador
            case 18: columna=col; break;    //casilla a la izquierda del jugador
          }
        break;
        
        case 0:
          switch (pos){
            case 1: columna=col-1; break;
            case 2: columna=col; break;
            case 3: columna=col+1; break;
            case 4: columna=col-2; break;
            case 5: columna=col-1; break;
            case 6: columna=col; break;
            case 7: columna=col+1; break;
            case 8: columna=col+2; break;
            case 9: columna=col-3; break;
            case 10: columna=col-2; break;
            case 11: columna=col-1; break;
            case 12: columna=col; break;
            case 13: columna=col+1; break;
            case 14: columna=col+2; break;
            case 15: columna=col+3; break;
            case 16: columna=col+1; break;    //casilla a la derecha del jugador
            case 17: columna=col; break;      //casilla detras del jugador
            case 18: columna=col-1; break;    //casilla a la izquierda del jugador
          }
        break;

        case 2:
          switch (pos){
            case 1: columna=col+1; break;
            case 2: columna=col+1; break;
            case 3: columna=col+1; break;
            case 4: columna=col+2; break;
            case 5: columna=col+2; break;
            case 6: columna=col+2; break;
            case 7: columna=col+2; break;
            case 8: columna=col+2; break;
            case 9: columna=col+3; break;
            case 10: columna=col+3; break;
            case 11: columna=col+3; break;
            case 12: columna=col+3; break;
            case 13: columna=col+3; break;
            case 14: columna=col+3; break;
            case 15: columna=col+3; break;
            case 16: columna=col; break;    //casilla a la derecha del jugador
            case 17: columna=col-1; break;  //casilla detras del jugador
            case 18: columna=col; break;    //casilla a la izquierda del jugador
          }
        break;

        case 4:
          switch (pos){
            case 1: columna=col+1; break;
            case 2: columna=col; break;
            case 3: columna=col-1; break;
            case 4: columna=col+2; break;
            case 5: columna=col+1; break;
            case 6: columna=col; break;
            case 7: columna=col-1; break;
            case 8: columna=col-2; break;
            case 9: columna=col+3; break;
            case 10: columna=col+2; break;
            case 11: columna=col+1; break;
            case 12: columna=col; break;
            case 13: columna=col-1; break;
            case 14: columna=col-2; break;
            case 15: columna=col-3; break;
            case 16: columna=col-1; break;    //casilla a la derecha del jugador
            case 17: columna=col; break;      //casilla detras del jugador
            case 18: columna=col+1; break;    //casilla a la izquierda del jugador
          }
        break;

		case 7:
          switch (pos){
            case 1: columna=col-1; break;
            case 2: columna=col-1; break;
            case 3: columna=col; break;
            case 4: columna=col-2; break;
            case 5: columna=col-2; break;
            case 6: columna=col-2; break;
            case 7: columna=col-1; break;
            case 8: columna=col; break;
            case 9: columna=col-3; break;
            case 10: columna=col-3; break;
            case 11: columna=col-3; break;
            case 12: columna=col-3; break;
            case 13: columna=col-2; break;
            case 14: columna=col-1; break;
            case 15: columna=col; break;
            //case 16: columna=col-1; break; //casilla a la derecha del jugador
            //case 17: columna=col; break;   //casilla detras del jugador
            //case 18: columna=col+1; break; //casilla a la izquierda del jugador
          }
        break;

		case 1:
          switch (pos){
            case 1: columna=col; break;
            case 2: columna=col+1; break;
            case 3: columna=col+1; break;
            case 4: columna=col; break;
            case 5: columna=col+1; break;
            case 6: columna=col+2; break;
            case 7: columna=col+2; break;
            case 8: columna=col+2; break;
            case 9: columna=col; break;
            case 10: columna=col+1; break;
            case 11: columna=col+2; break;
            case 12: columna=col+3; break;
            case 13: columna=col+3; break;
            case 14: columna=col+3; break;
            case 15: columna=col+3; break;
            //case 16: columna=col-1; break; //casilla a la derecha del jugador
            //case 17: columna=col; break;   //casilla detras del jugador
            //case 18: columna=col+1; break; //casilla a la izquierda del jugador
          }
        break;

		case 3:
          switch (pos){
            case 1: columna=col+1; break;
            case 2: columna=col+1; break;
            case 3: columna=col; break;
            case 4: columna=col+2; break;
            case 5: columna=col+2; break;
            case 6: columna=col+2; break;
            case 7: columna=col+1; break;
            case 8: columna=col; break;
            case 9: columna=col+3; break;
            case 10: columna=col+3; break;
            case 11: columna=col+3; break;
            case 12: columna=col+3; break;
            case 13: columna=col+2; break;
            case 14: columna=col+1; break;
            case 15: columna=col; break;
            //case 16: columna=col-1; break; //casilla a la derecha del jugador
            //case 17: columna=col; break;   //casilla detras del jugador
            //case 18: columna=col+1; break; //casilla a la izquierda del jugador
          }
        break;

		case 5:
          switch (pos){
            case 1: columna=col; break;
            case 2: columna=col-1; break;
            case 3: columna=col-1; break;
            case 4: columna=col; break;
            case 5: columna=col-1; break;
            case 6: columna=col-2; break;
            case 7: columna=col-2; break;
            case 8: columna=col-2; break;
            case 9: columna=col; break;
            case 10: columna=col-1; break;
            case 11: columna=col-2; break;
            case 12: columna=col-3; break;
            case 13: columna=col-3; break;
            case 14: columna=col-3; break;
            case 15: columna=col-3; break;
            //case 16: columna=col-1; break; //casilla a la derecha del jugador
            //case 17: columna=col; break;   //casilla detras del jugador
            //case 18: columna=col+1; break; //casilla a la izquierda del jugador
          }
        break;
      }
      return columna;
    }

// Localiza un objetivo según la casilla del vector terreno en la que está
void ComportamientoJugador::localizaObjetivo(estado &objetivo, int casilla){
	objetivo.fila = getFil(actual.orientacion, casilla);
	objetivo.columna = getCol(actual.orientacion, casilla);
}

// Indicar si una casilla no es nada de lo pasado en los parámetros
bool ComportamientoJugador::noEs(const char casilla, const string tipos){
	bool no_es=true;
	for(int i=0; i<tipos.length(); i++){
		if(casilla==tipos[i])
		no_es=false;
	}
	return no_es;
}

// Indicar si el jugador está rodeado del parámetro/parámetros
bool ComportamientoJugador::rodeado (const string tipos){
	bool rodeado = true;
	if(noEs(mapaResultado[getFil(actual.orientacion, 2)][getCol(actual.orientacion,2)], tipos))
		rodeado=false;
	for(int i=16; i<19; i++){
		if(noEs(mapaResultado[getFil(actual.orientacion, i)][getCol(actual.orientacion,i)], tipos))
		rodeado=false;
	}
	
	return rodeado;
}

// Traza el plan más barato hasta un objeto a la vista
list<Action> ComportamientoJugador::irAccesorio(int casilla){
	list <Action> plan;
	estado objetivo;
	localizaObjetivo(objetivo, casilla);
	pathFinding_CostoUniforme(actual, objetivo, plan);
	return plan;
}

// Salir de un entorno hostil (gasto alto de batería)
list<Action> ComportamientoJugador::SalirEntornoHostil(Sensores sensores){
	// CONDICIÓN PARA APLICAR:
	// else if(sensores.terreno[0]=='A' || sensores.terreno[0]=='B' || rodeado(types)){
	list<Action> acciones;
	int casilla;
	casilla = veoAccesorio(sensores, 'S');
	if(casilla != -1){
		acciones = irAccesorio(casilla);
	}	
	else{
		casilla = veoAccesorio(sensores, 'T');
		if(casilla != -1){
			acciones = irAccesorio(casilla);
		}	
		else if(sensores.terreno[2]!='P' && sensores.terreno[2]!='M'){
			Action accion=actFORWARD;
			acciones.push_back(accion);
		}
		else{
			Action accion = actTURN_R;
			acciones.push_back(accion);
		}
	}
	return acciones;
}

// Giro random
Action ComportamientoJugador::getRandomTurn()
{
	if(!girarDerecha)
	{
		return actTURN_L;
	}
	else
	{
		return actTURN_R;
	}
}

// Decide la acción a tomar de forma reactiva en caso de no tener éxito con los pasos deliberativos
list<Action> ComportamientoJugador::decideAction(Sensores sensores)
{
	Action accion = actIDLE;
	list<Action> planB;
	if(actual.orientacion%2!=0){
		accion = actSEMITURN_R;
		planB.push_back(accion);
		return planB;
	}

	if(sensores.superficie[6] == 'l') //accion de seguridad
	{
		cout << "lobo a la vista\n";
		accion = getRandomTurn();
		planB.push_back(accion);
		return planB;
	}
	
	if(	sensores.terreno[2] == 'P'
		|| sensores.terreno[2] == 'M') //accion de seguridad
	{
		accion = getRandomTurn();
		planB.push_back(accion);
		return planB;
	}
	if(sensores.superficie[2] != '_') //accion de seguridad
	{
		accion = actIDLE;
		planB.push_back(accion);
		return planB;
	}
	
	if(sensores.terreno[2] == 'X'
	||(sensores.terreno[2] == 'D' && !actual.zapatillas)
	||(sensores.terreno[2] == 'K' && !actual.bikini))
	{
		accion = actFORWARD;
		planB.push_back(accion);
		return planB;
	}

	if((!actual.zapatillas && (sensores.terreno[6] == 'D' || sensores.terreno[12] == 'D') && sensores.terreno[2] != 'A') //merece la pena cruzar agua para un bikini enfrente o bosque para unas zapatillas enfrente.
	|| (!actual.bikini && (sensores.terreno[6] == 'K' || sensores.terreno[12] == 'K') && sensores.terreno[2] != 'B'))
	{
		accion = actFORWARD;
		planB.push_back(accion);
		return planB;
	}

	if(andandoConPrecipicioAIzquierda)
	{
		andandoConPrecipicioAIzquierda = false;
		casillasSeguidasDePrecipicioAIzquierda = 0;
		accion = actTURN_R;
		planB.push_back(accion);
		return planB;
	}
	else if(andandoConPrecipicioADerecha)
	{
		andandoConPrecipicioADerecha = false;
		casillasSeguidasDePrecipicioADerecha = 0;
		accion = actTURN_L;
		planB.push_back(accion);
		return planB;
	}
	
	else if(sensores.terreno[2] == 'T'
		|| sensores.terreno[2] == 'S'
		|| (sensores.terreno[2] == 'B' && actual.zapatillas)
		|| (sensores.terreno[2] == 'A' && actual.bikini)
		|| (sensores.terreno[0] == 'B' && !actual.zapatillas)
		|| (sensores.terreno[0]) == 'A' && !actual.bikini)
	{
		accion = actFORWARD;
		planB.push_back(accion);
		return planB;
	}
	else if(sensores.terreno[0]=='A' || sensores.terreno[0]=='B' || rodeado(types)){
		planB = SalirEntornoHostil(sensores);
	}
	else {	
		accion = getRandomTurn();
		planB.push_back(accion);
		
	}
	
	return planB;
}

// Implementación de algoritmo de DESCUBRIR MAPA.
// Entra el punto de oigen y devuelve la
// siguiente acción en plan, la accion optima considerada para descubrir mapa.
bool ComportamientoJugador::pathFinding_Descubrir(const estado &origen, list<Action> &plan, Sensores sensores){
	Action accion = actIDLE;

	if(inicializar_nivel){
		inicializarNivel_3(sensores);
	}

	ActualizarVariablesEstado(sensores);
	pintarVista(sensores);
	
	if(empezar_girando){
		accion = empezarGirando();
	}
	
	if(accion == actIDLE){
		if(sensores.terreno[0]=='X' && sensores.bateria<4990 && contador_recarga<200 && 3000-instantes_tiempo>50){
			accion = actIDLE;
			contador_recarga++;
		}
		else{
			contador_recarga = 0;
			int casilla;
			if(casilla = veoAccesorio(sensores, 'K') != -1){
				plan = irAccesorio(casilla);
			}
			else if (casilla = veoAccesorio(sensores, 'D') != -1){
				plan = irAccesorio(casilla);
			}
			else if ( (sensores.bateria <=1500) && (3000-instantes_tiempo>50) && (casilla = veoAccesorio(sensores, 'X') != -1)){
				plan = irAccesorio(casilla);
			}
			else{
				if(!o_random){
					o_random = true;
					int rango = mapaResultado.size();
					objetivo_random.fila = rand()%(rango+1);
					objetivo_random.columna = rand()%(rango+1);
					bool comprobarF = true;
					bool comprobarC = true;
					
					while(comprobarF || comprobarC){
						// Compruebo que no me salgo fuera del rango del mapa
						if (objetivo_random.fila < 0 or objetivo_random.fila >= mapaResultado.size()){
							objetivo_random.fila = rand()%(rango+1);
						}
						else{
							comprobarF = false;
						}
						if (objetivo_random.columna < 0 or objetivo_random.columna >= mapaResultado[0].size()){
							objetivo_random.columna = rand()%(rango+1);
						}
						else{
							comprobarC = false;
						}
					}
					comprobarC = true;
					comprobarF = true;
					
					//pathFinding_CostoUniforme(actual, objetivo_random, planB);
					pathFinding_CostoUniforme(actual, objetivo_random, plan);
					PintaPlan(planB);
					// ver el plan en el mapa
					VisualizaPlan(actual, planB);
				}/*
				if(o_random){
					accion = planB.front();
					planB.erase(planB.cbegin());
					PintaPlan(planB);
					// ver el plan en el mapa
					VisualizaPlan(actual, planB);
				}
				*/
				switch(ultimaAccion)
				{
					case actFORWARD:
						#pragma region andandoJuntoAPrecipicio
						if(sensores.terreno[1] == 'P')
						{
							casillasSeguidasDePrecipicioAIzquierda++;
							if(casillasSeguidasDePrecipicioAIzquierda == 8) //numero justo para ir haciendo el zigzag y barrer un mapa vacio entero.
							{	andandoConPrecipicioAIzquierda = true;}
						}
						if(casillasSeguidasDePrecipicioAIzquierda > 0 && sensores.terreno[1] != 'P')
						{	casillasSeguidasDePrecipicioAIzquierda = 0;}

						if(sensores.terreno[3] == 'P')
						{
							casillasSeguidasDePrecipicioADerecha++;
							if(casillasSeguidasDePrecipicioADerecha == 8)
							{	andandoConPrecipicioADerecha = true;}
						}
						if(casillasSeguidasDePrecipicioADerecha > 0 && sensores.terreno[3] != 'P')
						{	casillasSeguidasDePrecipicioADerecha = 0;}
						#pragma endregion
	
						break;
					case actTURN_L:
						girarDerecha = (rand()%2==0);
						break;
					case actTURN_R:
						girarDerecha = (rand()%2==0);
						break;
				}
				
				//plan = decideAction(sensores);
				
				
			}
		}
	}

	if(plan.empty())
		plan.push_back(accion);
	if(plan.size()!=0){
		return true;
	}
	else{
		cout << "No encontrado plan (SIG_Acción)\n";
		return false;
	}
}

// Sacar por la consola la secuencia del plan obtenido
void ComportamientoJugador::PintaPlan(list<Action> plan)
{
	auto it = plan.begin();
	while (it != plan.end())
	{
		if (*it == actFORWARD)
		{
			cout << "A ";
		}
		else if (*it == actTURN_R)
		{
			cout << "D ";
		}
		else if (*it == actSEMITURN_R)
		{
			cout << "d ";
		}
		else if (*it == actTURN_L)
		{
			cout << "I ";
		}
		else if (*it == actSEMITURN_L)
		{
			cout << "I ";
		}
		else
		{
			cout << "- ";
		}
		it++;
	}
	cout << endl;
}

// Funcion auxiliar para poner a 0 todas las casillas de una matriz
void AnularMatriz(vector<vector<unsigned char>> &m)
{
	for (int i = 0; i < m[0].size(); i++)
	{
		for (int j = 0; j < m.size(); j++)
		{
			m[i][j] = 0;
		}
	}
}

// Pinta sobre el mapa del juego el plan obtenido
void ComportamientoJugador::VisualizaPlan(const estado &st, const list<Action> &plan)
{
	AnularMatriz(mapaConPlan);
	estado cst = st;

	auto it = plan.begin();
	while (it != plan.end())
	{
		if (*it == actFORWARD)
		{
			switch (cst.orientacion)
			{
			case 0:
				cst.fila--;
				break;
			case 1:
				cst.fila--;
				cst.columna++;
				break;
			case 2:
				cst.columna++;
				break;
			case 3:
				cst.fila++;
				cst.columna++;
				break;
			case 4:
				cst.fila++;
				break;
			case 5:
				cst.fila++;
				cst.columna--;
				break;
			case 6:
				cst.columna--;
				break;
			case 7:
				cst.fila--;
				cst.columna--;
				break;
			}
			mapaConPlan[cst.fila][cst.columna] = 1;
		}
		else if (*it == actTURN_R)
		{
			cst.orientacion = (cst.orientacion + 2) % 8;
		}
		else if (*it == actSEMITURN_R)
		{
			cst.orientacion = (cst.orientacion + 1) % 8;
		}
		else if (*it == actTURN_L)
		{
			cst.orientacion = (cst.orientacion + 6) % 8;
		}
		else if (*it == actSEMITURN_L)
		{
			cst.orientacion = (cst.orientacion + 7) % 8;
		}
		it++;
	}
}

int ComportamientoJugador::interact(Action accion, int valor)
{
	return false;
}
